#!/bin/bash -eu
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
################################################################################


LDFLAGS=""
TEMP_SANITIZER=""

if [[ $SANITIZER == "introspector" ]]; then
  export SANITIZER=address
  # Remove ASAN from the makefile though
  sed -i 's/LDFLAGS+=-fsanitize=address/# LDFLAGS+=-fsanitize=address/g' src/Makefile
  sed -i 's/CFLAGS+=-fsanitize=address -fno-sanitize-recover=all/CFLAGS+=-fno-sanitize-recover=all/g' src/Makefile
  TEMP_SANITIZER="introspector"
  export CXXFLAGS="$CXXFLAGS -flto -std=c++20"
  export LDFLAGS="-flto -fuse-ld=lld -Wl,-plugin-opt=O0 -Wl,--export-dynamic"
fi

if [[ $SANITIZER == "address" && $TEMP_SANITIZER != "introspector" ]]; then
  export CXXFLAGS="$CXXFLAGS -flto -std=c++20"
  export LDFLAGS="-fsanitize=address -flto -fuse-ld=lld -Wl,-plugin-opt=O0 -Wl,--export-dynamic"
fi

export LD=ld.lld
export OPT="$CFLAGS"
export OPTIMIZATION="$CFLAGS"

sed -i 's/\$(error \"unknown sanitizer/#sdfsdf/g' src/Makefile

make -j "$(nproc)" all BUILD_TLS=yes BUILD_WITH_MODULES=yes INSTALL_RUST_TOOLCHAIN=yes DISABLE_WERRORS=yes OPT="$OPT" OPTIMIZATION="$OPTIMIZATION" CFLAGS="$CFLAGS" LDFLAGS="$LDFLAGS" V=1

# Recompile server.c to avoid duplicate main functions.
sed -i 's/int main(/int main2(/g' src/server.c

$CC $CFLAGS -Wall -Wno-missing-field-initializers -std=gnu11 \
  -g -ggdb \
  -Ideps/hiredis \
  -Ideps/linenoise \
  -Ideps/lua/src \
  -Ideps/hdr_histogram \
  -Ideps/fpconv \
  -Ideps/fast_float \
  -I. -Isrc \
  -c src/server.c -o src/server.o

llvm-ar rcs libredis.a $(find src -type f -name '*.o' \
  ! -name 'redis-cli.o' \
  ! -name 'cli_commands.o' \
  ! -name 'redis-benchmark.o' \
  ! -name 'redisassert.o')

DEPENDENCIES="$SRC/redis/modules/redisearch/src/deps/readies/wd40/linux-x64/libbb.a"
for lib in $(find . -name '*.a' ! -name 'libbb.a'); do
  lib_path=$(realpath "$lib")
  ranlib "$lib_path"
  DEPENDENCIES="$DEPENDENCIES $lib_path"
done

for fuzzer in $(find $SRC -maxdepth 1 -name 'fuzz_*.c'); do
  fuzzer_basename=$(basename $fuzzer)
  $CC $CFLAGS $fuzzer -o $OUT/${fuzzer_basename} $LDFLAGS \
      -I. -Isrc -L. -Wl,--start-group -Wl,--whole-archive libredis.a \
      -Wl,--no-whole-archive $DEPENDENCIES \
      -l:libcrypto.a -l:libssl.a -Wl,--end-group \
      $LIB_FUZZING_ENGINE
done

if [[ $TEMP_SANITIZER == "introspector" ]]; then
  export SANITIZER="introspector"
fi

# Clean up some files we don't need for fuzz introspector post processing.
rm -rf $SRC/redis/modules/redisearch/src/bin/


