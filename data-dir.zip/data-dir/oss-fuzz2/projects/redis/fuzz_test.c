#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "adlist.h"

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    // printf("Hello world\n");
    // Insert fuzzer contents here
    // input string contains fuzz input.
    long long val1;

    char *ns = (char*)malloc(size+1);
    memcpy(ns, data, size);
    ns[size] = '\0';

    string2ull(ns, &val1);
    
    free(ns);
    // end of fuzzer contents

    return 0;
}
